Coloque aqui banners e ícones para a página do plugin no WordPress.org.
Tamanhos: banner-772x250.png/jpg, banner-1544x500.png/jpg, icon-128x128.png/jpg, icon-256x256.png/jpg.
